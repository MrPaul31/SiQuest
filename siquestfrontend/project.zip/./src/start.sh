#!/bin/bash
npm start > /opt/utils/log/npm.log
